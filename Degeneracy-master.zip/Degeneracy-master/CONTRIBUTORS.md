# List of contributors to Degeneracy:

## Developers

* [Degenerate](https://github.com/Degen-dev)
* [EnderKingJ](https://github.com/EnderKingJ)

## Contributors 

* [Luphoria](https://github.com/luphoria)
* [Nebelung](https://github.com/Nebelung-dev)

## Donators

* [EnderKingJ](https://github.com/EnderKingJ)
* siggaddj#3621